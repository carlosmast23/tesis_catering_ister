
UPDATE `#__cck_core_fields` SET `options` = 'Alphanumeric=alnum||Array=array||Float=float||Int=int||Integers=integers||String=string||Word=word' WHERE `id` = 264;
