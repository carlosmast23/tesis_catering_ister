
UPDATE `#__cck_core_fields` SET `options` = 'Both=||None=none||Location=optgroup||Administrator=admin||Site=site' WHERE `id` = 284;

UPDATE `#__cck_core_fields` SET `options` = 'Joomla=optgroup||Activation=activation||Block=block||Checkbox=selection||Checkbox Label For=selection_label||Dropdown Menu=dropdown||Featured=featured||Increment=increment||Reordering=sort||Reordering Grip=sort_grip||Status=state||SEBLOD=optgroup||Form=form||Hidden=form_hidden||Form Disabled=form_disabled' WHERE `id` = 271;