
UPDATE `#__cck_core_fields` SET `options` = 'Construction=0||Free=1||Function=optgroup||Query getTableList=2' WHERE `id` = 81;

UPDATE `#__cck_core_fields` SET `bool2` = '2', `options2` = '{}' WHERE `id` = 29;