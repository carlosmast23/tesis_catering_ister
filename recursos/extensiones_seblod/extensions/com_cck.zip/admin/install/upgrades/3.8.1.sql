
UPDATE `#__cck_core_fields` SET `storage` = 'none', `storage_location` = '', `storage_table` = '' WHERE `id` = 604;