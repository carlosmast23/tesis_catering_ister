
UPDATE `#__cck_core_fields` SET `options` = '_=0||Alter Original Table=1||Alter Original Field=2' WHERE `id` = 192;