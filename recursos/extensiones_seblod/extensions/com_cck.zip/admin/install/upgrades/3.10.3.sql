
UPDATE `#__cck_core_fields` SET `options2` = REPLACE( `options2`, '$.fn.colorbox(', '$.colorbox(' ) WHERE `id` = 457;