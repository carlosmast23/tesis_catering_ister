
ALTER TABLE `#__cck_core_types` ADD `permissions` VARCHAR(255) NOT NULL AFTER `parent`;