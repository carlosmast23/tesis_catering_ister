
UPDATE `#__cck_core_fields` SET `options` = 'No=0||Auto=1' WHERE `id` = 222;