
UPDATE `#__cck_core_fields` SET `options` = 'Hide=0||Show=optgroup||At the right of FormValue=4||Below Field=1||Below FormValue=2||Below Label=3||Popover=5' WHERE `id` = 154;