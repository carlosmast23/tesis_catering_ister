
UPDATE `#__cck_core_fields` SET `storage` = 'standard', `storage_field` = 'tags', `storage_field2` = '' WHERE `id` IN (472,473,474,475);