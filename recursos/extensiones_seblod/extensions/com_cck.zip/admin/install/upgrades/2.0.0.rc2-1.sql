
UPDATE `#__cck_core_fields` SET `options` = 'Sum=0||Product=1||Difference=2||Quotient=3' WHERE `id` = 60;
UPDATE `#__cck_core_fields` SET `options` = 'Datetime=DATETIME||Decimal 10 2=DECIMAL(10,2)||Int 11=INT(11)||Varchar 50=VARCHAR(50)||Varchar 255=VARCHAR(255)||Varchar 2048=VARCHAR(2048)||Text=TEXT||Tinyint 3=TINYINT(3)' WHERE `id` = 76;
UPDATE `#__cck_core_fields` SET `options` = 'No Process=||Add Color=addcolor||Crop=crop||Max Fit=maxfit||Stretch=stretch' WHERE `id` = 117;
UPDATE `#__cck_core_fields` SET `options` = 'Default=0||Email=1||Field=3' WHERE `id` = 124;
UPDATE `#__cck_core_fields` SET `options` = 'Auto=1||Specific=2' WHERE `id` = 133;
UPDATE `#__cck_core_fields` SET `options` = 'No=0||Yes Featured=1' WHERE `id` = 162;
UPDATE `#__cck_core_fields` SET `options` = 'All Dates=0||Past=1||Past Today=2||Today Future=3||Future=4' WHERE `id` = 166;
UPDATE `#__cck_core_fields` SET `options` = 'No=0||12=12||24=24' WHERE `id` = 168;
UPDATE `#__cck_core_fields` SET `options` = 'Index Follow=index, follow||No index follow=noindex, follow||Index No follow=index, nofollow||No index no follow=noindex, nofollow' WHERE `id` = 383;
UPDATE `#__cck_core_fields` SET `options` = 'Index Follow=index, follow||No index follow=noindex, follow||Index No follow=index, nofollow||No index no follow=noindex, nofollow' WHERE `id` = 349;
UPDATE `#__cck_core_fields` SET `type` = 'jform_helpsite', `selectlabel` = '', `options` = '' WHERE `id` = 370;