
ALTER TABLE `#__cck_core_templates` ADD `options` VARCHAR(2048) NOT NULL AFTER `featured`;