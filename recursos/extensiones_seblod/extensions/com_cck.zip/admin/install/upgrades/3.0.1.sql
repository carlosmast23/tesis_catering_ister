
UPDATE `#__cck_core_fields` SET `storage_table` = '#__content' WHERE `id` = 472;
UPDATE `#__cck_core_fields` SET `storage_table` = '#__categories' WHERE `id` = 473;
UPDATE `#__cck_core_fields` SET `storage_table` = '#__users' WHERE `id` = 474;
UPDATE `#__cck_core_fields` SET `storage_table` = '#__usergroups' WHERE `id` = 475;