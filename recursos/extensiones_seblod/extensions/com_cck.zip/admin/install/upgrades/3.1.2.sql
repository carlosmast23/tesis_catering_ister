
UPDATE `#__cck_core_fields` SET `required` = 'required' WHERE `id` = 271;